# Pointer

This package provides some functions for pointer-based operations.
