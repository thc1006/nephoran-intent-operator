# Reporting a security issue

The Prometheus security policy, including how to report vulnerabilities, can be
found here:

<https://prometheus.io/docs/operating/security/>
