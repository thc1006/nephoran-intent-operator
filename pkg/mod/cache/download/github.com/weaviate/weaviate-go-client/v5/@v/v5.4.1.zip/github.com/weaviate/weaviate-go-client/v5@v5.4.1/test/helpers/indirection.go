package helpers

func StringPointer(s string) *string {
	return &s
}

func Float64Pointer(f float64) *float64 {
	return &f
}
